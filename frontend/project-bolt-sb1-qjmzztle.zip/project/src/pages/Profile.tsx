import React from 'react';
import { motion } from 'framer-motion';
import Card from '../components/ui/Card';
import Avatar from '../components/ui/Avatar';
import Button from '../components/ui/Button';
import SkillsCard from '../components/profile/SkillsCard';
import BadgesCard from '../components/profile/BadgesCard';
import { currentUser } from '../data/mockData';

const Profile: React.FC = () => {
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="sm:flex items-start space-y-4 sm:space-y-0 sm:space-x-4 p-6">
          <Avatar 
            src={currentUser.avatar} 
            alt={currentUser.name} 
            size="xl" 
            className="mx-auto sm:mx-0"
          />
          <div className="flex-1">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{currentUser.name}</h1>
                <p className="text-gray-600">{currentUser.position}, {currentUser.department}</p>
              </div>
              <Button variant="outline">Edit Profile</Button>
            </div>
            <div className="mt-4 sm:mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-sm font-medium text-gray-500">Email</p>
                <p className="mt-1 font-medium">{currentUser.email}</p>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-sm font-medium text-gray-500">Role</p>
                <p className="mt-1 font-medium capitalize">{currentUser.role}</p>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-sm font-medium text-gray-500">Total Badges</p>
                <p className="mt-1 font-medium">{currentUser.badges.length}</p>
              </div>
            </div>
          </div>
        </Card>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <SkillsCard skills={currentUser.skills} />
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <BadgesCard badges={currentUser.badges} />
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <Card>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium">Training Activity</h2>
            <Button variant="outline" size="sm">View All</Button>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div>
                <h3 className="font-medium">Advanced React Patterns</h3>
                <p className="text-sm text-gray-600 mt-1">Completed Module 2/4</p>
              </div>
              <Button variant="primary" size="sm">Continue</Button>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div>
                <h3 className="font-medium">JavaScript Fundamentals Refresher</h3>
                <p className="text-sm text-gray-600 mt-1">Completed Course</p>
              </div>
              <Button variant="outline" size="sm">Certificate</Button>
            </div>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default Profile;